# Phising-Game-Online
# Mobile Legend & Clash of Clans

tools phising untuk game : mobile legends & clash of clans

=> Installation :

pkg install python2 -y
pip2 install requests
pkg install figlet -y
pkg install nano -y
pkg install git -y
git clone https://github.com/Cyser-Inc/Phising-Game-Online

=> how to use : 

cd Phising-Game-Online
python2 phising.py
"pilih salah satunya"
1 = Clash of Clans
2 = Mobile Legends
3 = Exit (Keluar)

kemudian copy linknya : http://127.0.0.1:8080
buka melalui browser (Google Chrome)
Finish :)

+ Untuk melihat email & sandi nya di dalam folder :
1 = Clash of Clans
2 = Mobile Legends

Subscribe My Channel : https://www.youtube.com/channel/UCaLCTn0hb-G2GxO8cJ4fOrA

by Cyser Inc.
